
This folder contains any module manager configs for the mod.
See the comments inside each file for details.